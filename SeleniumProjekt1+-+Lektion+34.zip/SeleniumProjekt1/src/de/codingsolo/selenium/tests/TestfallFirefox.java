package de.codingsolo.selenium.tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestfallFirefox {

	public static void main(String[] args) {
		System.out.println("Hallo Welt");
		WebDriver driver=new FirefoxDriver();
	}

}
